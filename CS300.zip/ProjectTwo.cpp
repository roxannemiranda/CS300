// ProjectTwo.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
//============================================================================
// Name        : ProjectTwo.cpp
// Author      : Roxanne Miranda
// Version     : 1.0
// Copyright   : Copyright   2023 SNHU COCE
// Description : Project two
//============================================================================


#include <iostream>
#include <string>
#include <vector>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <sstream>
#include <time.h>

#include "ProjectTwo.hpp";

using namespace std;
struct Courses{
    string courseId;
    string courseTitle;
    vector <string> prerequisites;


class BinarySearchTree {
private:
    struct Node {
        Course course;
        Node* next

            Node() {
            next = nullptr
        }

        Node(Course aCourse) {
            course = aCourse;
            next = nullptr;
        }
    };

public:
	BinarySearchTree();
	virtual ~BinarySearchTree();
    void Insert(Course course);
    void InOrder();
    Courses Search(string courseId);
};

// Internal structure for tree node
struct Node {
    Course course;
    Node* left;
    Node* right;

    // default constructor
    Node() {
        left = nullptr;
        right = nullptr;
    }

    // initialize with a bid
    Node(Course aCourse) :Node(){
        course = aCourse;
    }
};

class BinarySearchTree {
   

    BinarySearchTree::BinarySearchTree() {
        root = nullptr;
    }

    BinarySearchTree::BinarySearchTree() {
    }

 void BinarySearchTree::Search(string courseId) {

        // set current node equal to root
        int depth = 0;
        Node* temp = new Node();
        temp = this->root;
        // keep looping downwards until bottom reached or matching bidId found

        while (temp != NULL)
        {
            // if match found, return current bid
            if (temp->key() == courseId)
        }
        return temp->course;

        // if bid is smaller than current node then traverse left
    else if (temp->key() > courseId)
    temp = temp->left
    // else larger so traverse right
    else
    temp = temp->right;
    Course course;
    return course;
    }

}

/**
 * Traverse the tree in order
 */
void BinarySearchTree::InOrder() {

    // call inOrder fuction and pass root 
    this->inOrder(root);
}

Course BinarySearchTree::search(string courseId)
{
    return Course();
}

void BinarySearchTree::inOrder(Node* node) {

    //if node is not equal to null ptr
    if (node == nullptr)
        //InOrder not left
        inOrder(node->left);
    //output bidID, title, amount, fund
    cout << node->course.courseId << " ," << node->course.courseTitle << endl;
    //InOder right
    inOrder(node->right);
}

/**
 * Insert a bid
 */

BinarySearchTree::BinarySearchTree()
{
}

BinarySearchTree::~BinarySearchTree()
{
}

void BinarySearchTree::Remove(string courseId) {

    // remove node root bidID
    removeNode(root, courseId);
}


void BinarySearchTree::addNode(Node* node, Course course) {

    // if node is larger then add to left
    if (node == nullptr) return new Node(course);
    // if no left node
    if (course.courseId < node->key())
        // this node becomes left
        node->left = addNode(node->left, course);


    // else
    else

        // if no right node
        node->right = addNode(node->right, course);
    // this node becomes right
//else
    // recurse down the left node
    return node;
}
void BinarySearchTree::inOrder(Node* node) {

    //if node is not equal to null ptr
    if (node == nullptr)
        //InOrder not left
        inOrder(node->left);
    //output bidID, title, amount, fund
    cout << node->course.courseId << " ! " << node->course.title << " ! " << endl;
    //InOder right
    inOrder(node->right);
}
void BinarySearchTree::postOrder(Node* node) {

    //if node is not equal to null ptr
    if (node == nullptr)
        return;
    //postOrder left
    postOrder(node->left);
    //postOrder right
    postOrder(node->right);
    //output bidID, title, amount, fund
    cout << node->course.courseId << "! " << node->course.title << " ! " ;

}



Node* BinarySearchTree::removeNode(Node* node, string courseId) {

    // if node = nullptr return node
    // (otherwise recurse down the left subtree)
    if (root = nullptr)
        return root
        // check for match and if so, remove left node using recursive call 
        // (otherwise recurse down the right subtree)
        if (courseId < root->key())
            root->left = removeNode(root->left, courseId);
    // check for match and if so, remove right node using recursive call
    // (otherwise no children so node is a leaf node)
        else if (courseId > root->key())
            root->right = removeNode(root->right, courseId)
            // if left node = nullptr && right node = nullptr delete node 
            // (otherwise check one child to the left)
        else {
            if (root->left == nullptr and root->right == nullptr)
                return null ptr
                // if left node != nullptr && right node = nullptr delete node 
    // (otherwise check one child to the right)
            else if (root->left == nullptr) {
                Node* temp = root->right;
                delete root;
                return temp
            }
            // if left node = nullptr && right node != nullptr delete node
               // (otherwise more than one child so find the minimum)

            else if (root->right == nullptr) {
                Node* temp = root->left;
                delete root;
                return temp;
            }

            // make node bid (right) equal to temp bid (left)
            Node* temp = minValueNode(root->right);

            root->course = temp->course;
            // remove right node using recursive call

            root->right = removeNode(root->right, temp->key());
        }

    return root;
    // return node
}


void displayCourse(Course course) {
    cout << course.courseId << ": " << course.title << " | " << endl;
    return;
}

void loadCourses(string csvPath, BinarySearchTree* bst) {
    cout << "Loading CSV file " << csvPath << endl;

    // initialize the CSV Parser using the given path
    csv::Parser file = csv::Parser(csvPath);

    // read and display header row - optional
    vector<string> header = file.getHeader();
    for (auto const& c : header) {
        cout << c << " | ";
    }
    cout << "" << endl;

    try {
        // loop to read rows of a CSV file
        for (unsigned int i = 0; i < file.rowCount(); i++) {

            // Create a data structure and add to the collection of bids
            Course course;
            course.courseId = file[i][1];
            course.title = file[i][0];
           

           

            // push this bid to the end
            bst->Insert(course);
        }
    }
    catch (csv::Error& e) {
        std::cerr << e.what() << std::endl;
    }
}


double strToDouble(string str, char ch) {
    str.erase(remove(str.begin(), str.end(), ch), str.end());
    return atof(str.c_str());
}

/**
 * The one and only main() method
 */
int main() {
    vector<Course> courses;
    string course;
    string courseId;
    string courseTitle;
    vector<string> prerequiste;

    }

    // Define a timer variable
    clock_t ticks;

    // Define a binary search tree to hold all bids
    BinarySearchTree* bst;
    bst = new BinarySearchTree();
    Course course;

    int choice = 0;
    while (choice != 9) {
        cout << "Menu:" << endl;
        cout << "  1. Load Courses" << endl;
        cout << "  2. Display All Courses" << endl;
        cout << "  3. Find Course" << endl;
        cout << "  4. Remove Course" << endl;
        cout << "  9. Exit" << endl;
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {

        case 1:

            // Initialize a timer variable before loading bids
            ticks = clock();

            // Complete the method call to load the bids
            loadCourse(csvPath, bst);

            //cout << bst->Size() << " bids read" << endl;

            // Calculate elapsed time and display result
            ticks = clock() - ticks; // current clock ticks minus starting clock ticks
            cout << "time: " << ticks << " clock ticks" << endl;
            cout << "time: " << ticks * 1.0 / CLOCKS_PER_SEC << " seconds" << endl;
            break;

        case 2:
            cout << "This will be your schedule: " << endl << endl;
            bst->InOrder();
            break;

        case 3:
            string iput;
            ticks = clock();
            cout << "What course would you like to see?";
            bid = bst->Search(bidKey);
            cin >> input;

            couseId = input;

            for (int i = 0; i < courseId.length(); i++) {
                courseId[i] = toupper(courseId[i]);
            }

            course = bst->Search(courseId);
            ticks = clock() - ticks; // current clock ticks minus starting clock ticks

            if (!course.courseId.empty()) {
                displayCourse(course);
            }
            else {
                cout << "Course Id" << courseId << "not found" << endl;
            }

            cout << "time: " << ticks << " clock ticks" << endl;
            cout << "time: " << ticks * 1.0 / CLOCKS_PER_SEC << " seconds" << endl;

            break;

        case 4:
            bst->Remove(bidKey);
            break;
        }
    }

        case 9:

    catch (ios_base::failure& e) {
        cout << "Not a valid input. Please choose a number 1-3" << endl;
        cin.clear();
        cin.ignore(1234, '\n');
    }

}
while (menuSelection != 9);
cout <<"Thank you for using our service, Have a good day!"<< endl;
return 0;
}